chrome.alarms.onAlarm.addListener(function (alarm) {
  chrome.notifications.create("", {
    title: "Todo Reminder",
    message: `Reminder: ${alarm.name}`,
    iconUrl: "images/icon128.png",
    type: "basic",
  });
});
