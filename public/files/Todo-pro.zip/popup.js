document.addEventListener("DOMContentLoaded", function () {
  const input = document.getElementById("todo-input");
  const addBtn = document.getElementById("add-btn");
  const todoList = document.getElementById("todo-list");

  // Load existing todos
  chrome.storage.sync.get(["todos"], function (result) {
    const todos = result.todos || [];
    todos.forEach((todo) => addTodoToList(todo.text, todo.complete));
  });

  addBtn.addEventListener("click", function () {
    const todoText = input.value.trim();
    if (todoText) {
      addTodoToList(todoText, false);
      saveTodoToStorage(todoText);
      input.value = "";
    }
  });

  todoList.addEventListener("click", function (event) {
    if (event.target.classList.contains("complete-btn")) {
      const todoItem = event.target.parentElement.parentElement;
      toggleComplete(todoItem);
    } else if (event.target.classList.contains("remove-btn")) {
      const todoItem = event.target.parentElement.parentElement;
      const todoText = todoItem.querySelector(".todo-text").textContent;
      removeTodoFromStorage(todoText);
      todoItem.remove();
    } else if (event.target.classList.contains("settimebtn")) {
      const timeBtns = event.target.nextElementSibling;
      timeBtns.classList.toggle("show");
    } else if (event.target.classList.contains("notification-btn")) {
      const time = parseInt(event.target.dataset.time, 10);
      const todoItem = event.target.closest("li");
      const todoText = todoItem.querySelector(".todo-text").textContent;
      scheduleNotification(time, todoText);
    }
  });

  function addTodoToList(todoText, complete) {
    const li = document.createElement("li");
    if (complete) li.classList.add("complete");

    li.innerHTML = `
            <span class="todo-text">${todoText}</span>
            <div class="todo-actions">
                <button class="complete-btn">C</button>
                <button class="remove-btn">R</button>
                <button class="settimebtn">Set Time</button>
                <div class="notification-time">
                    <button class="notification-btn" data-time="1">1 min</button>
                    <button class="notification-btn" data-time="10">10 min</button>
                    <button class="notification-btn" data-time="30">30 min</button>
                    <button class="notification-btn" data-time="60">60 min</button>
                    <button class="notification-btn" data-time="120">120 min</button>
                </div>
            </div>
        `;

    todoList.appendChild(li);
  }

  function saveTodoToStorage(todoText) {
    chrome.storage.sync.get(["todos"], function (result) {
      const todos = result.todos || [];
      todos.push({ text: todoText, complete: false });
      chrome.storage.sync.set({ todos: todos });
    });
  }

  function toggleComplete(todoItem) {
    const todoText = todoItem.querySelector(".todo-text").textContent;
    chrome.storage.sync.get(["todos"], function (result) {
      const todos = result.todos || [];
      const updatedTodos = todos.map((todo) => {
        if (todo.text === todoText) {
          todo.complete = !todo.complete;
        }
        return todo;
      });
      chrome.storage.sync.set({ todos: updatedTodos });
    });

    todoItem.classList.toggle("complete");
  }

  function removeTodoFromStorage(todoText) {
    chrome.storage.sync.get(["todos"], function (result) {
      let todos = result.todos || [];
      todos = todos.filter((todo) => todo.text !== todoText);
      chrome.storage.sync.set({ todos: todos });
    });
  }

  function scheduleNotification(minutes, todoText) {
    const delay = minutes * 60000; // Convert minutes to milliseconds

    // Clear any existing alarms for the same task to avoid duplicates
    chrome.alarms.clear(todoText, () => {
      chrome.alarms.create(todoText, { delayInMinutes: minutes });

      chrome.notifications.create(todoText, {
        type: "basic",
        iconUrl: "images/icon128.png",
        title: "To-Do Reminder",
        message: `Reminder for task: "${todoText}" in ${minutes} minutes.`,
        priority: 2,
      });
    });
  }

  // Listen for the alarm
  chrome.alarms.onAlarm.addListener(function (alarm) {
    chrome.notifications.create(alarm.name, {
      type: "basic",
      iconUrl: "images/icon128.png",
      title: "To-Do Reminder",
      message: `Time to work on: ${alarm.name}`,
      priority: 2,
    });
  });
});
